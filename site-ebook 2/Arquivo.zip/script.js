// Funções de Segurança
function sanitizeInput(input) {
    return input.replace(/[<>]/g, '');
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function preventXSS(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Proteção contra ataques de força bruta
const loginAttempts = new Map();
const MAX_ATTEMPTS = 5;
const LOCKOUT_TIME = 15 * 60 * 1000; // 15 minutos

function checkLoginAttempts(identifier) {
    const attempts = loginAttempts.get(identifier) || { count: 0, timestamp: Date.now() };
    
    if (attempts.count >= MAX_ATTEMPTS) {
        const timeElapsed = Date.now() - attempts.timestamp;
        if (timeElapsed < LOCKOUT_TIME) {
            return false;
        }
        loginAttempts.delete(identifier);
    }
    return true;
}

function recordLoginAttempt(identifier) {
    const attempts = loginAttempts.get(identifier) || { count: 0, timestamp: Date.now() };
    attempts.count++;
    loginAttempts.set(identifier, attempts);
}

// Proteção contra CSRF
function generateCSRFToken() {
    return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

const csrfToken = generateCSRFToken();

// Proteção contra clickjacking
if (window.self !== window.top) {
    window.top.location = window.self.location;
}

// Proteção contra XSS em inputs
document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.addEventListener('input', function(e) {
            this.value = sanitizeInput(this.value);
        });
    });
});

// Menu Toggle
const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');

menuToggle.addEventListener('click', () => {
    nav.classList.toggle('active');
});

// FAQ Toggle
document.addEventListener('DOMContentLoaded', function() {
    // Seleciona todos os itens FAQ
    const faqItems = document.querySelectorAll('.faq-item, .benefit-faq .faq-item');
    
    // Adiciona evento de clique para cada item
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        const icon = question.querySelector('i');
        
        question.addEventListener('click', () => {
            // Fecha todos os outros itens
            faqItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                    otherItem.querySelector('.faq-answer').style.maxHeight = '0';
                    otherItem.querySelector('.faq-question i').style.transform = 'rotate(0deg)';
                }
            });
            
            // Toggle do item atual
            item.classList.toggle('active');
            
            if (item.classList.contains('active')) {
                answer.style.maxHeight = answer.scrollHeight + 'px';
                icon.style.transform = 'rotate(180deg)';
            } else {
                answer.style.maxHeight = '0';
                icon.style.transform = 'rotate(0deg)';
            }
        });
    });
});

// Terms and Privacy Toggle
document.addEventListener('DOMContentLoaded', function() {
    // Elementos principais
    const terms = document.querySelector('.terms');
    const privacyPolicy = document.querySelector('.privacy-policy');
    const mainSections = document.querySelectorAll('section:not(.terms):not(.privacy-policy)');
    const nav = document.querySelector('nav');

    // Função para esconder todas as seções
    function hideAllSections() {
        mainSections.forEach(section => {
            section.style.display = 'none';
        });
        if (terms) terms.style.display = 'none';
        if (privacyPolicy) privacyPolicy.style.display = 'none';
    }

    // Função para mostrar todas as seções principais
    function showMainSections() {
        mainSections.forEach(section => {
            section.style.display = 'block';
        });
        if (terms) terms.style.display = 'none';
        if (privacyPolicy) privacyPolicy.style.display = 'none';
    }

    // Função para mostrar termos
    function showTerms() {
        hideAllSections();
        if (terms) {
            terms.style.display = 'block';
            terms.classList.add('active');
        }
    }

    // Função para mostrar privacidade
    function showPrivacy() {
        hideAllSections();
        if (privacyPolicy) {
            privacyPolicy.style.display = 'block';
            privacyPolicy.classList.add('active');
        }
    }

    // Função para mostrar seção específica
    function showSection(sectionId) {
        showMainSections();
        const section = document.querySelector(sectionId);
        if (section) {
            section.scrollIntoView({ behavior: 'smooth' });
        }
    }

    // Adiciona eventos para todos os links
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const href = this.getAttribute('href');
            
            // Fecha o menu mobile se estiver aberto
            if (nav) nav.classList.remove('active');

            // Navegação
            switch(href) {
                case '#home':
                    showMainSections();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    break;
                    
                case '#terms-link':
                case '#footer-terms-link':
                    showTerms();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    break;
                    
                case '#privacy-link':
                case '#footer-privacy-link':
                    showPrivacy();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    break;
                    
                default:
                    showMainSections();
                    setTimeout(() => showSection(href), 100);
            }
        });
    });
});

// Back to Top Button
window.onscroll = function() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.querySelector('.back-to-top').style.display = "block";
    } else {
        document.querySelector('.back-to-top').style.display = "none";
    }
};

document.querySelector('.back-to-top').addEventListener('click', function(e) {
    e.preventDefault();
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Smooth Scroll for Navigation Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        if (this.getAttribute('href') !== '#') {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
                // Fecha o menu mobile se estiver aberto
                nav.classList.remove('active');
            }
        }
    });
});

// Animação de entrada dos elementos
const animateOnScroll = () => {
    const elements = document.querySelectorAll('.benefit-card, .testimonial-card, .faq-item');
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementBottom = element.getBoundingClientRect().bottom;
        
        if (elementTop < window.innerHeight && elementBottom > 0) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
};

window.addEventListener('scroll', animateOnScroll);
window.addEventListener('load', animateOnScroll);

// Cookie Banner
document.addEventListener('DOMContentLoaded', function() {
    const cookieBanner = document.getElementById('cookieBanner');
    const acceptCookies = document.getElementById('acceptCookies');
    const declineCookies = document.getElementById('declineCookies');

    // Verifica se o usuário já fez uma escolha
    const cookieChoice = localStorage.getItem('cookieChoice');
    if (!cookieChoice) {
        setTimeout(() => {
            cookieBanner.classList.add('active');
        }, 1000);
    }

    // Função para aceitar cookies
    acceptCookies.addEventListener('click', () => {
        localStorage.setItem('cookieChoice', 'accepted');
        cookieBanner.classList.remove('active');
        // Aqui você pode adicionar o código para ativar os cookies
    });

    // Função para recusar cookies
    declineCookies.addEventListener('click', () => {
        localStorage.setItem('cookieChoice', 'declined');
        cookieBanner.classList.remove('active');
        // Aqui você pode adicionar o código para desativar os cookies
    });
});

// Função para verificar a integridade dos links de checkout
function verifyCheckoutLink(link) {
    const originalLinks = {
        main: 'https://pay.kiwify.com.br/aSRuF2T',
        combo: 'https://pay.kiwify.com.br/j3sgUtB'
    };

    const linkType = link.getAttribute('data-checkout');
    const currentHref = link.getAttribute('href');

    if (linkType && originalLinks[linkType] && currentHref !== originalLinks[linkType]) {
        // Se o link foi modificado, restaura o original
        link.setAttribute('href', originalLinks[linkType]);
        console.warn('Link de checkout modificado detectado e restaurado');
    }

    return true;
}

// Verificação periódica dos links
setInterval(() => {
    document.querySelectorAll('a[data-checkout]').forEach(link => {
        verifyCheckoutLink(link);
    });
}, 5000);

// Registro do Service Worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('ServiceWorker registrado com sucesso:', registration.scope);
            })
            .catch(error => {
                console.log('Falha ao registrar o ServiceWorker:', error);
            });
    });
}

// Detecção de dispositivo e otimizações
const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
const isTablet = /iPad|Android/i.test(navigator.userAgent) && !/Mobile/i.test(navigator.userAgent);

// Otimizações para dispositivos móveis
if (isMobile) {
    // Reduz animações em dispositivos móveis
    document.documentElement.style.setProperty('--animation-duration', '0.3s');
    
    // Otimiza imagens para carregamento
    document.querySelectorAll('img').forEach(img => {
        img.loading = 'lazy';
    });
}

// Otimizações para tablets
if (isTablet) {
    // Ajusta tamanho de fonte para tablets
    document.documentElement.style.setProperty('--base-font-size', '16px');
}

// Detecção de conexão
window.addEventListener('online', () => {
    document.body.classList.remove('offline');
});

window.addEventListener('offline', () => {
    document.body.classList.add('offline');
}); 